class Main extends egret.DisplayObjectContainer {

    public constructor() {
        super();

        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.init, this);

        this.x = 100;
        this.y = 300;
        this.scaleX = 0.8;
        this.scaleY = 0.8;
        this.rotation = 30;
    }

    private init(e:egret.Event):void {
        var qr:one.QRShape
        egret.setTimeout(()=> { 
            qr = new one.QRShape(200);
            this.addChild(qr);
            qr.x = 100;
            qr.y = 100;
            qr.make("http://www.egret.com");
        }, this, 100);

        var text:egret.TextField = new egret.TextField();
        text.type = egret.TextFieldType.INPUT;
        this.addChild(text);
        text.x = 100;
        text.y = 350;
        text.width = 200;
        text.height = 430;
        text.border = true;
        text.multiline = false;

        var label:egret.TextField = new egret.TextField();
        this.addChild(label);
        label.x = 330;
        label.y = 350;
        label.size = 50;
        label.text = "执行";
        label.touchEnabled = true;
        label.addEventListener(egret.TouchEvent.TOUCH_TAP, function (e:egret.TouchEvent):void {
            qr.make(text.text.trim());
        }, this);

        var input:one.WebInput = new one.WebInput();
        this.addChild(input);
        input.x = 330;
        input.y = 400;
        // input.size = 50;
        input.width = 300;
        input.height = 100;
        // input.text = "执行";

        var label:egret.TextField = new egret.TextField();
        this.addChild(label);
        label.x = 330;
        label.y = 600;
        label.size = 50;
        label.text = "创建 iframe";
        label.touchEnabled = true;
        label.addEventListener(egret.TouchEvent.TOUCH_TAP, (e:egret.TouchEvent)=> {
            // let iframe = document.createElement("iframe");
            // iframe.src = "http://developer.egret.com";
            // let webNode = new one.WebNode();
            // webNode.bind(iframe);

            let webNode = new one.WebView();
            webNode.src = "http://developer.egret.com";
            webNode.width = 500;
            webNode.height = 600;
            webNode.x = 100;
            webNode.y = 300;
            
            this.addChild(webNode);
        }, this);
    }
}