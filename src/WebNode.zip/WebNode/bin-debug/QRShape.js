var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var one;
(function (one) {
    /**
     * 二维码生成器
     */
    var QRShape = (function (_super) {
        __extends(QRShape, _super);
        function QRShape(size) {
            var _this = _super.call(this) || this;
            _this.webNode = new one.WebNode();
            _this.size = size;
            _this.shape = new egret.Shape();
            // if (egret.Capabilities.runtimeType != egret.RuntimeType.WEB) {
            _this.addChild(_this.shape);
            // }
            // else {
            _this.addChild(_this.webNode);
            return _this;
            // }
        }
        /**
         * 生成
         */
        QRShape.prototype.make = function (msg) {
            var qrcode = new QRCode();
            qrcode.makeCode(msg);
            var points = qrcode.getPoints();
            this.shape.graphics.clear();
            this.shape.graphics.beginFill(0x000000, 1);
            var length = points.length;
            for (var i = 0; i < length; i++) {
                var lines = points[i];
                for (var j = 0; j < lines.length; j++) {
                    if (lines[j]) {
                        this.shape.graphics.drawRect(this.size / length * i, this.size / length * j, this.size / length, this.size / length);
                    }
                }
            }
            this.shape.graphics.endFill();
            if (egret.Capabilities.runtimeType == egret.RuntimeType.WEB) {
                this.addToDOM();
            }
        };
        /**
         * 显示到HTML中，方便微信等识别二维码
         * 请在位置等确定后在执行，不然位置很有可能对不上
         */
        QRShape.prototype.addToDOM = function () {
            if (this.img == null) {
                this.img = document.createElement("img");
                this.webNode.bind(this.img);
                this.webNode.width = this.size;
                this.webNode.height = this.size;
            }
            this.updateImg();
        };
        QRShape.prototype.updateImg = function () {
            var renterTexture = new egret.RenderTexture();
            renterTexture.drawToTexture(this.shape);
            this.img.src = renterTexture.toDataURL("image/png");
        };
        return QRShape;
    }(egret.DisplayObjectContainer));
    one.QRShape = QRShape;
    __reflect(QRShape.prototype, "one.QRShape");
})(one || (one = {}));
