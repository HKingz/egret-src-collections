var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Main = (function (_super) {
    __extends(Main, _super);
    function Main() {
        var _this = _super.call(this) || this;
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.init, _this);
        _this.x = 100;
        _this.y = 300;
        _this.scaleX = 0.8;
        _this.scaleY = 0.8;
        _this.rotation = 30;
        return _this;
    }
    Main.prototype.init = function (e) {
        var _this = this;
        var qr;
        egret.setTimeout(function () {
            qr = new one.QRShape(200);
            _this.addChild(qr);
            qr.x = 100;
            qr.y = 100;
            qr.make("http://www.egret.com");
        }, this, 100);
        var text = new egret.TextField();
        text.type = egret.TextFieldType.INPUT;
        this.addChild(text);
        text.x = 100;
        text.y = 350;
        text.width = 200;
        text.height = 430;
        text.border = true;
        text.multiline = false;
        var label = new egret.TextField();
        this.addChild(label);
        label.x = 330;
        label.y = 350;
        label.size = 50;
        label.text = "执行";
        label.touchEnabled = true;
        label.addEventListener(egret.TouchEvent.TOUCH_TAP, function (e) {
            qr.make(text.text.trim());
        }, this);
        var input = new one.WebInput();
        this.addChild(input);
        input.x = 330;
        input.y = 400;
        // input.size = 50;
        input.width = 300;
        input.height = 100;
        // input.text = "执行";
        var label = new egret.TextField();
        this.addChild(label);
        label.x = 330;
        label.y = 600;
        label.size = 50;
        label.text = "创建 iframe";
        label.touchEnabled = true;
        label.addEventListener(egret.TouchEvent.TOUCH_TAP, function (e) {
            // let iframe = document.createElement("iframe");
            // iframe.src = "http://developer.egret.com";
            // let webNode = new one.WebNode();
            // webNode.bind(iframe);
            var webNode = new one.WebView();
            webNode.src = "http://developer.egret.com";
            webNode.width = 500;
            webNode.height = 600;
            webNode.x = 100;
            webNode.y = 300;
            _this.addChild(webNode);
        }, this);
    };
    return Main;
}(egret.DisplayObjectContainer));
__reflect(Main.prototype, "Main");
