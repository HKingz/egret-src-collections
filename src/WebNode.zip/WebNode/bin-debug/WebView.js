var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var one;
(function (one) {
    var WebView = (function (_super) {
        __extends(WebView, _super);
        function WebView() {
            var _this = _super.call(this) || this;
            _this.iframe = document.createElement("iframe");
            _this.bind(_this.iframe);
            return _this;
        }
        Object.defineProperty(WebView.prototype, "src", {
            get: function () {
                return this._src;
            },
            set: function (v) {
                this._src = v;
                this.iframe.src = v;
            },
            enumerable: true,
            configurable: true
        });
        return WebView;
    }(one.WebNode));
    one.WebView = WebView;
    __reflect(WebView.prototype, "one.WebView");
})(one || (one = {}));
